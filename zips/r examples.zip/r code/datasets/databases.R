# Real world data

# Read in file
dat <- read.csv(file="KeysarEtAl2000.csv", header=TRUE)

# SubjectID 
# cond contidion ( e= competitor, c= noncompetitor)
# crit moment of onset of critical word (frames)
# targfix moment the hand touched the target (frames)
# object name of the experimental item

# 60 frames a second
# 1000 ms to a second
frames.ms <- (1/60)*1000
dat$latency <- dat$targfix - dat$crit
dat$tfix <- dat$latency*frames.ms

# Histogram
hist(dat$tfix)

cutoff <- quantile(dat$tfix, probs=.975, na.rm=TRUE)
dat$tfix[dat$tfix > cutoff]
dat$tfixTrunc <- ifelse(dat$tfix > cutoff, cutoff, dat$tfix)
hist(dat$tfixTrunc)
summary(dat)

#
dat.agg <- aggregate(tfixTrunc ~ cond + SubjID ,dat, mean)
grp1 <- subset(dat.agg, cond=="E")
grp2 <- subset(dat.agg, cond=="C")

# Paired T-test
t.test(grp1$tfixTrunc,grp2$tfixTrunc, paired=TRUE)

dat$SubjID <- factor(dat$SubjID)
dat$cond <- factor(dat$cond)

# ANOVA
dat.aov <- aov(tfixTrunc ~ cond + Error(SubjID/cond), data=dat)
summary(dat.aov)

library(lme4)
# Highly recommended that you create a numerical varibales out of your categrorical vars (cond)

dat$C <- ifelse(dat$cond=="C", -.5, .5)

# Testing the effect of C
dat.mod <- lmer(tfixTrunc ~ C + (C|SubjID)+(C|object), dat, REML=FALSE)
dat.mod.noC <- lmer(tfixTrunc ~(C|SubjID)+(C|object), dat, REML=FALSE)
anova(dat.mod, dat.mod.noC)

summary(dat.mod)

# BLUPS
blups <- ranef(dat.mod)