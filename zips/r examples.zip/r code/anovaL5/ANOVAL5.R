
# Two Factor Between Subjects ANOVA

list.files()

load(file="anova2f.Rdata", verbose=TRUE)
summary(dat.2x2)

dat.2x2$A <- factor(dat.2x2$A)
dat.2x2$B <- factor(dat.2x2$B)

dat.2x2.aov <- aov(Y ~ A*B, data= dat.2x2)
dat.2x2.aov <- aov(Y ~ A+B+A:B, data=dat.2x2)

model.tables(dat.2x2.aov, type="means")
interaction.plot(dat.2x2$A, dat.2x2$B, dat.2x2$Y)
with(dat.2x2, interaction.plot(A, B, Y))

summary(dat.2x2.aov)

# One Factor Within Subjects ANOVA

load(file="dat1fw.RData", verbose="TRUE")
head(dat.1fw, 10)

is.factor(dat.1fw$A)
dat.1fw$A <- factor(dat.1fw$A)
dat.1fw$SubjID <- factor(dat.1fw$SubjID)

summary(dat.1fw)

with(dat.1fw, interaction.plot(A, SubjID, Y))
boxplot( Y ~ A, data = dat.1fw)

dat.1fw.aov <- aov(Y ~ A + Error(SubjID/A), data=dat.1fw)
summary(dat.1fw.aov)

# Multifactor ANOVA

load(file="dat2x2ws.RData", verbose=TRUE)
dat.2x2ws

summary(dat.2x2ws)

dat.2x2ws$SubjID <- factor(dat.2x2ws$SubjID)
dat.2x2ws$A <- factor(dat.2x2ws$A)
dat.2x2ws$A
dat.2x2ws$B <- factor(dat.2x2ws$B)
dat.2x2ws.aov <- aov(Y ~ A*B+Error(SubjID/(A*B)), dat.2x2ws)
model.tables(dat.2x2ws.aov, type="means") # broken ???
with(dat.2x2ws.aov, interaction.plot(A, B, Y))

summary(data.2x2ws.aov)

# Mixed-Designs

load(file="datmix1.RData", verbose=TRUE)
summary(dat.mix1)

dat.mix1.aov <- aov(Y ~ A * B * C + Error(SubjID/A), dat.mix1)
model.tables(dat.mix1.aov, type="means")

with(subset(dat.mix1, C=="C1"), interaction.plot(A,B,Y))
with(subset(dat.mix1, C=="C2"), interaction.plot(A,B,Y))

summary(dat.mix1.aov)

# Follow-ups

dat.mix1.c1 <- aov(Y ~ A*B + Error(SubjID/A),data=subset(dat.mix1, C=="C1"))
summary(dat.mix1.aov.c1)

dat.mix1.c2 <- aov(Y ~ A*B + Error(SubjID/A),data=subset(dat.mix1, C=="C2"))
summary(dat.mix1.aov.c2)

# One between, two within

load(file="datmix2.RData", verbose=TRUE)
summary(dat.mix2)
head(dat.mix2, 12)
dat.mix2.aov <- aov(Y ~ A*B*C + Error(SubjID/(A*B)), dat.mix2)
summary(dat.mix2.aov)

# Checking assumptions

plot(dat.mix2.aov) # broken

# General Recipe for ANOVA
	# Make IVs and DVs as factors
	# If data are unbalanced and/or IVs are correlated:
		# options(contrast=c(unordered='contr.sum', ordered='contr.poly))
		# before running aov()
	# Run aov(), store the model object in var mod
	# Use model.tables(mod, "means") to extract cell marginal means
	# Visualize the data
	# If data are balanced and IVs are uncorrelated:
		# Use summary(mod) to get results
	# If data are unbalanced and/or IVs are correlated:
		# Between Ss: Use drop1(mod, scope=c("A", "B", "A:B"), test='F') for results
		# Within Ss or Mixed: use linear-mixed effects modeling
	# Check assumptions using plot(mod)
