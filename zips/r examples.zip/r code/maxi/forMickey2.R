load(file="pog.RData", verbose=TRUE)
load(file="stg.RData", verbose=TRUE)
load(file="droid.RData", verbose=TRUE)

library(plyr)

# Get transition rates
getRuns <- function(x) {
    x$ID <- as.character(x$ID)
    ff <- rle(x$ID)
    ix <- c(1, (cumsum(ff$lengths)+1)[-length(ff$lengths)])
    data.frame(lengths=ff$lengths, values=ff$values, ms=x[ix,"ms"])
}
#fs
binCount <- function(x) {
    xtabs(~binf, x)
}

# Eyetracking data
res <- ddply(pog, .(RespID,SessionID,ItemID), getRuns)
res.nox <- subset(res, values!="X")

binwidth <- 200
res.nox$bin <- floor((res.nox$ms+(binwidth/2))/binwidth)*binwidth
res.nox$binf <- factor(res.nox$bin)

res.bin <- ddply(res.nox, .(SessionID), binCount)
res.bin.mx <- daply(res.nox, .(SessionID), binCount)
bins <- as.numeric(dimnames(res.bin.mx)$binf)

subj <- split(t(res.bin.mx), rep(1:ncol(t(res.bin.mx)), each=nrow(t(res.bin.mx))))
colors <- rainbow(length(subj), alpha=.5)

plot(bins, rep(NA, length(bins)), type='n', ylim=c(0,50), xlim=c(-500,2000))
mapply(function(x, y) {
    points(bins, x, type='l', col=y)
}, subj, colors)

apply(res.bin.mx, 1, function(x) {
    points(bins, x, type='l')
})

# Controller data
res.stg <- ddply(stg, .(RespID,SessionID,ItemID), getRuns)
res.stg$bin <- floor((res.stg$ms+(binwidth/2))/binwidth)*binwidth
res.stg&binf <- factor(res.stg$bin)

# Android data
res.doid <- ddply(droid, .(RespID,SessionID,ItemID), getRuns)
res.droid$bin <- floor((res.droid$ms+(binwidth/2))/binwidth)*binwidth
res.droid&binf <- factor(res.droid$bin)

##################OUTPUT#########################

binnedData <- xtabs(~bin, res.nox)
plot(binnedData, type='l', ylim=c(0,1000))
points(binnedData-100, type='l', ylim=c(0,1000), col='red')
abline(v=0, lty=2)
legend("topleft", legend=c("Eye tracking", "Button"), col=c("black","red"), lty=1)

xtabs(~bin, res.nox)

x <- subset(res.nox, RespID==673)

countTransitions <- function(x) {
    d1 <- subset(x, ms<0)
    d2 <- subset(x, ms>=0)
    data.frame(before=nrow(d1), after=nrow(d2))
}

ddply(res.nox, .(RespID, SessionID, ItemID), countTransitions)
ddply(stg, .(RespID, SessionID, ItemID), countTransitions)

ddply(res.nox, .(RespID, SessionID, ItemID), nrow)
