load(file="pog.sess.RData")
load(file="stg.RData")
load(file="droid.RData")

library(plyr)

getRuns <- function(x) {
    x$ID <- as.character(x$ID)
    ff <- rle(x$ID)
    ix <- c(1, (cumsum(ff$lengths)+1)[-length(ff$lengths)])
    data.frame(lengths=ff$lengths, values=ff$values, ms=x[ix,"ms"])
}

res <- ddply(pog.sess, .(RespID,SessionID,ItemID), getRuns)

res.nox <- subset(res, values!="X")

x <- subset(res.nox, RespID==673)

countTransitions <- function(x) {
    d1 <- subset(x, ms<0)
    d2 <- subset(x, ms>=0)
    data.frame(before=nrow(d1), after=nrow(d2))
}

ddply(res.nox, .(RespID, SessionID, ItemID), countTransitions)
ddply(stg, .(RespID, SessionID, ItemID), countTransitions)

ddply(res.nox, .(RespID, SessionID, ItemID), nrow)
