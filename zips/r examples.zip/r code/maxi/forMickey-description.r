# TO-DO 
# barplot of the means of the transitions before/after onset for each data set
# subject variability ddply, subset functions SessionID = subject
# comparison of the transition probabilities



# load		Reload datasets written with the function save
# verbose	should item names be printed during loading
# pog		point of gaze 			eyetracking data set
# stg		scroll tracking gaze	controller data set
# droid								smartphone data set
load(file="pog.sess.RData", verbose=TRUE)
load(file="stg.RData", verbose=TRUE)
load(file="droid.RData", verbose=TRUE)

# loads package
# plyr		uses the split-apply-combine pattern
library(plyr)

# Takes in a data frame and returns a data frame with the number of transitions
getRuns <- function(x) {
	# What is x
	# What is ID
	x$ID <- as.character(x$ID)	# coerces the argument (ie x$ID) to type char
	ff <- rle(x$ID)				# Run Lenght Encoding compute lenght and vals of runs of equal vals in a vector
	# ix is a vector from 1 to 
	# Cumulative sums returns a vector whose elements are the cumulative sums (a,b,c...) -> (a,a+b, a+b+c, ...)
	ix <- c(1, (cumsum(ff$lenght)+1)[-lenght(ff$lenght)])
	# creates a data frame with row names lenghts | values | ms
	# What is lenghts
	# What is values
	# ms is the onset of the transition
	data.frame(lenghts=ff$lenghts, values=ff$values, ms=x[ix,"ms"])
}

# I/O d - data frame
# split pog data frame by RespID, SessionID, ItemID
# apply the getRuns function
res <- ddply(pog.sess, .RespID,SessionID,ItemID),getRuns)

# Data from with no X (ie nox)
res.nox <- subset(res, values!="X")

# Bin is like a time window (onset at -8000ms to 200-250-500ms)
# binwidth denotes the size of the bin in ms
binwidth <- 200
# floor rounds the number to the nearest decimal point
# binf - f denotes factor
res.nox$bin <- floor((res.nox$ms+(binwidth/2))/binwidth)*binwidth
res.nox$binf <- factor(res.nox$bin)

binCount <- function(x) {
	xtabs(~binf, x)
}

res.bin <- ddply(res.nox, .(SessionID), binCount)
res.bin.mx <- daply(res.nox, .(SessionID), binCount)
bins <- as.numeric(dimnames(res.bin.mx)$binf)
