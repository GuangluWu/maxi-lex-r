
# Regression

# lm(), coef(), anova(), predict(), residuals(), fitted.values()
# rnorm(), runif(), scale()

sample.size <- 100; pop.var <- 10
x <- runif(sample.size, min=0, max=10)
y <- 0 + 2*x + rnorm(sample.size, sd=sqrt(pop.var))
plot(x, y)

mod1 <- lm(y ~ x)
summary(mod1)
