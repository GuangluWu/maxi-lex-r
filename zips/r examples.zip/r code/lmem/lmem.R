
nsubj <- 24; nitem <- 24; mu <- 600
trials <- expand.grid(SubjID=factor(1:nsubj),
                      ItemID=factor(1:nitem))
trials$e.ij <- rnorm(nrow(trials), sd=50)
sre <- data.frame(SubjID=factor(1:nsubj),
                  u.i=rnorm(nsubj, sd=200))
ire <- data.frame(ItemID=factor(1:nitem),
                  v.i=rnorm(nitem, sd=100))
trials1 <- merge(trials, ire)
trials2 <- merge(trials1, sre)
trials2$Y <- mu + trials2$u.i + trials2$v.i + trials2$e.ij
head(trials2, 4)

library(lme4)
m1 <- lmer(Y ~ (1 | SubjID) + (1 | ItemID), data=trials2)
summary(m1)

rfx <- ranef(m1)
with(trials2, plot(SubjID, u.i))
points(factor(1:nsubj), rfx$SubjID[,1], col='red')

source("mlsetup.R")
dat <- genml(eff=0)
with(dat, aggregate(list(Y=Y), list(Type=Type), mean)) # means
# also try: with(dat, plot(factor(Type), Y))

library(lme4)
dat.mm1 <- lmer(Y ~ Type + (1 + Type | SubjID) + (1 | ItemID), data=dat,
               REML=FALSE) # use maximum likelihood
summary(dat.mm1)

dat.mm2 <- lmer(Y ~ (1 + Type | SubjID) + (1 | ItemID), data=dat,
                REML=FALSE)
anova(dat.mm1, dat.mm2)

vc1 <- VarCorr(dat.mm1)
vc1
