
genml <- function(mu=800, eff=40, err.sd=20, subj.sd=c(b0=100, b1=100), subj.corr=.6, item.sd=c(b0=40),
                  nsubj=24, nitem=24) {
  subj.cov <- prod(subj.sd)*subj.corr
  err <- round(rnorm(nsubj*nitem, sd=err.sd))

  library(MASS)
  smx <- mvrnorm(nsubj,
                 Sigma=matrix(c(subj.sd["b0"]^2, subj.cov, subj.cov, subj.sd["b1"]^2), nrow=2),
                 mu=c(0,0))
  smx[,2] <- round(smx[,2]/2)*2
  smx2 <- apply(smx, 2, round)
  ire <- round(rnorm(nitem, sd=item.sd["b0"]))
  
  wsbi <- data.frame(SubjID=rep(1:nsubj,each=nitem),
                     ItemID=1:nitem,
                     Type=rep(c(-.5,.5), each=nitem/2),
                     mu=800,
                     S.0i=rep(smx2[,1], each=nitem),
                     I.0j=ire,
                     A=(eff/2)*rep(c(-1,1), each=nitem/2),
                     S.1i=rep(smx2[,2]/2, each=nitem)*rep(c(-1,1), each=nitem/2),
                     e.ij=err)

  wsbi$Y <- with(wsbi, mu + S.0i + I.0j + A + S.1i + e.ij)
  wsbi <- wsbi[,c("SubjID","ItemID","Type","Y",setdiff(colnames(wsbi), c("SubjID","ItemID","Type","Y")))]
  return(wsbi)
}
