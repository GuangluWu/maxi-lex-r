
load(file="preprocessed.RData")

alldat <- do.call("rbind", by(dat4, dat4$RespID, function(x) {
  minms <- max(subset(x, ms<0)$ms)
  if (max(x$ms) < 1500) {
    # add in "fake" frame after
    x <- rbind(x, data.frame(RespID=x[1,"RespID"], ms=1501, AOI=x[nrow(x),"AOI"]))
  }
  maxms <- min(subset(x, ms>1500)$ms)
  ff <- subset(x, ms>=minms & ms<=maxms)
  ff2 <- merge(cbind(ff,ix=2:(nrow(ff)+1)), cbind(ff,ix=1:nrow(ff)), by="ix")
  ff3 <- merge(ff2, data.frame(Msec=seq(0,1500,24)))
  subset(ff3, Msec>=ms.x & Msec < ms.y)[,c("RespID.x","Msec","AOI.x")]
}))

save(alldat, file="alldat.RData")
