
pdf(file="/home/daleb/Dropbox/lex.pdf",height=6,width=6)
load(file="preprocessed.RData")
load(file="alldat.RData")

colnames(alldat) <- sub("\\.x$", "", colnames(alldat))
rownames(alldat) <- NULL

mx <- as.matrix(xtabs(~AOI+Msec, alldat))
props <- mx / apply(mx, 2, sum)

bins <- seq(0,1488,24)
plot(bins, rep(NA, length(bins)), ylim=c(0,1), type='n', xlab="Time from Onset (ms)", ylab="pGaze")

lineinfo <- list(PComp=list(mpch=1,mcol='blue'),
                 SComp=list(mpch=2,mcol='green'),
                 Targ=list(mpch=3,mcol='red'),
                 Unrl=list(mpch=4,mcol='gray50'))

lapply(rownames(props), function(x) {
  inf <- lineinfo[[x]]
  points(bins, props[x,], type='b', pch=inf$mpch, col=inf$mcol)
})
dev.off()
