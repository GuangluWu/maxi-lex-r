#!/bin/bash

for f in `ls response | grep -v "\..*\.txt$"`
do
    thisfile=response/$f
    ./parsefile.sh $thisfile
done
R --no-save < preprocess.R
R --no-save < toframes.R
R --no-save < plot.R
R --no-save < bysession.R
R --no-save < accuracy.R
R --no-save < sessinfo.R
gs -sDEVICE=pdfwrite -dNOPAUSE -dBATCH -dSAFER -sOutputFile=bysess.pdf bysession/*.pdf
